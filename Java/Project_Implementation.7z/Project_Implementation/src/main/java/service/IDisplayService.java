package service;

public interface IDisplayService {
    void printDailyForecast();
    void printHourForecast();
}

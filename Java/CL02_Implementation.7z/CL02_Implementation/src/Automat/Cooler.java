package Automat;

public class Cooler {
}

package Automat;

public class OutputTray {

}

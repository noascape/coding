package Enumeration;

public enum BeverageType {
    WATER, APPLEJUICE, NONALCOHOLICBEER, NONALCOHOLICGIN, TONIC
}

package Enumeration;

public enum Manufacturer {
    AB, IQ
}
